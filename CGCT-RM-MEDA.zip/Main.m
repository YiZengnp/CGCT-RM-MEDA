clear
clc
warning('off', 'all');
cd(fileparts(mfilename('fullpath')));
addpath(genpath(cd));

% -------------------- Parallel Pool(parfor) ------------------------------
MyCluster=parcluster('local');
MyCluster.NumWorkers = 10; % 可根据需求或计算机的核心数设定
parpool(MyCluster,MyCluster.NumWorkers)
% -------------------------------------------------------------------------

Problem = {'DF1','DF2','DF3','DF4','DF5','DF6','DF7', ...
    'DF8','DF9', 'DF10','DF11','DF12','DF13','DF14'};
compareAlgorithms = {'CGCT'};
timeParameter = [
    5 5
    10 5
    5 10
    10 10];
preEvolution = 50;
change = 50;
repMax = 30;
N = 100;
M = 2;
D = 10;
for cp = 1:length(compareAlgorithms)
    Algorithm = compareAlgorithms{cp};
    for tp = 1:size(timeParameter,1)
        nt = timeParameter(tp,1);
        ft = timeParameter(tp,2);
        for p = 1:length(Problem)
            if p>=10&&p<=14
                N=150;
                M=3;
            else
                N=100;
                M=2;
            end

            % -------------------------- Run ------------------------------
            clearvars res
            problem_name = Problem{p};
            parfor rep=1:repMax
                res{rep}=DMOEA(problem_name,Algorithm,ft,nt,preEvolution,change,N,D,rep);
                population{rep} = res{rep}.FinalPop;
                allMIGD(rep) = res{rep}.MIGD;
                allMHV(rep)  = res{rep}.MHV;
                allRT(rep)   = res{rep}.runtime;
            end

            % ----------------------- Save Results ------------------------
        end
    end
end



function res = DMOEA(Problem,Algorithm,ft,nt,preEvolution,change,N,D,rep)

    maxgen = preEvolution + change*ft;
    [IniPopulation,boundary,N,M] = Individual(Problem,ft,nt,1,N,D,preEvolution);

    % ---------------------------------------------------------------------
    fprintf('\n%s  %s  nt:%d  ft:%d  rep:%d\n',Algorithm,Problem,nt,ft,rep);
    tic;
    FinalPop = feval(Algorithm,Problem,IniPopulation,boundary,N,D,M,maxgen,ft,nt,preEvolution);
    runtime = toc;
    PF = GeneratePF(Problem,ft,nt,maxgen,preEvolution);
    for i = 1:change+1
        igd(i) = IGD(FinalPop(i,:).objs,PF(i).PF);
        hv(i) = HV(FinalPop(i,:).objs,PF(i).PF);
    end
    MIGD = mean(igd,'omitnan');
    MHV = mean(hv,'omitnan');
    fprintf('\nMIGD:%d     MHV:%d\nruntime:%d', MIGD, MHV, runtime);
    % ---------------------------------------------------------------------

    res.Problem = Problem;
    res.Algorithm = Algorithm;
    res.FinalPop = FinalPop;
    res.runtime = runtime;
    res.igd = igd;
    res.hv = hv;
    res.MIGD = MIGD;
    res.MHV = MHV;
end
