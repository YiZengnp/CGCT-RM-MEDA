function Population = RMMEDA(Problem,ft,nt,gen,N,D,preEvolution,Population,boundary)
% Generate offsprings by the models

%------------------------------- Copyright --------------------------------
% Copyright (c) 2024 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

% This function is modified from the code in
% http://dces.essex.ac.uk/staff/zhang/IntrotoResearch/RegEDA.htm

    %% Parameter setting
    K = 5;
    PopDec = Population.decs;
    M      = length(Population(1).obj);
    
    %% Modeling
    [Model,probability] = LocalPCA(PopDec,M,K);

    %% Reproduction
    OffspringDec = zeros(N,D);
    % Generate new trial solutions one by one
    for i = 1 : N
        % Select one cluster by Roulette-wheel selection
        k = find(rand<=probability,1);
        % Generate one offspring
        if ~isempty(Model(k).eVector)
            lower = Model(k).a - 0.25*(Model(k).b-Model(k).a);
            upper = Model(k).b + 0.25*(Model(k).b-Model(k).a);
            trial = rand(1,M-1).*(upper-lower) + lower;
            sigma = sum(abs(Model(k).eValue(M:D)))/(D-M+1);
            OffspringDec(i,:) = Model(k).mean + trial*Model(k).eVector(:,1:M-1)' + randn(1,D)*sqrt(sigma);
        else
            OffspringDec(i,:) = Model(k).mean + randn(1,D);
        end
    end

    Lower = repmat(boundary.lower,N,1);
    Upper = repmat(boundary.upper,N,1);
    OffspringDec(OffspringDec<Lower) = Lower(OffspringDec<Lower);
    OffspringDec(OffspringDec>Upper) = Upper(OffspringDec>Upper);

    Offspring = Individual(Problem,ft,nt,gen,[],D,preEvolution,OffspringDec);
    Population = RMMEDAEnvironment([Population,Offspring],N);
end