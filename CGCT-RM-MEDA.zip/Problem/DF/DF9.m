classdef DF9 < handle
    % <problem> <DF>
    % Dynamic MOP benchmark JY
    % ft --- --- frequency of change
    % nt --- --- severity of change
    properties(SetAccess = private)
        obj;  % the objective value
        dec;  % the decision vector
        con;  % the constraint violations
        add;  % Additional properties of the individual
    end
    methods
        %% Initialization
        function obj = DF9(ft,nt,gen,Dec,preEvolution,AddProper)
            if nargin > 0
                N = size(Dec,1);
                obj(1,N) = DF9;
                %% calculate objective value
                if gen < preEvolution
                    t = 0;
                else
                    t = floor((gen-preEvolution)/ft+1)* 1/nt;
                end
              Nt = 1 + floor(10*abs(sin(0.5*pi*t)));
              g = 1 + sum((Dec(:,2:end)- cos(4*t+Dec(:,1)+Dec(:,1:end-1))).^2,2);

                Obj(:,1) = g.* (Dec(:,1) + max(0,(1/2/Nt+0.1)*sin(2*Nt*pi*Dec(:,1))));
                Obj(:,2) = g.* (1 - Dec(:,1) + max(0,(1/2/Nt+0.1)*sin(2*Nt*pi*Dec(:,1))));
                %% calculate constraint violations
                Con = zeros(size(Dec,1),1);
                %% generate population
                for i = 1 : length(obj)
                    obj(i).dec = Dec(i,:);
                    obj(i).obj = Obj(i,:);
                    obj(i).con = Con(i,:);
                end
                if nargin > 5
                    for i = 1 : length(obj)
                        obj(i).add = AddProper(i,:);
                    end
                end
            end
        end
        %% Get the matrix of decision variables of the population
        function value = decs(obj)
            %decs - Get the matrix of decision variables of the population.
            value = cat(1,obj.dec);
        end
        %% Get the matrix of objective values of the population
        function value = objs(obj)
            %objs - Get the matrix of objective values of the population.
            value = cat(1,obj.obj);
        end
        %% Get the matrix of constraint violations of the population
        function value = cons(obj)
            %cons - Get the matrix of constraint violations of the population.
            value = cat(1,obj.con);
        end
        function value = adds(obj,AddProper)
            %adds - Get the matrix of additional properties of the population.
            for i = 1 : length(obj)
                if isempty(obj(i).add)
                    obj(i).add = AddProper(i,:);
                end
            end
            value = cat(1,obj.add);
        end
        %% Get the best solutions among multiple solutions.
        function P = best(obj)
        %   P = obj.best returns the feasible and non-dominated solutions
        %   among multiple solutions obj. If the solutions have a single
        %   objective, the feasible solution with minimum objective value
        %   is returned.
            N = length(obj);
            [FrontNo,~] = NDSort(obj.objs,N);
            P = obj(find(FrontNo==1));
        end
    end
    methods (Static)
        %% Sample reference points on Pareto front
        function P = PF(ft,nt,maxgen,preEvolution)
            Dec = (0:1/(1000-1):1)';
            for i = 1 : ceil((maxgen-preEvolution)/ft+1)
                pf = [];
                t  = (i-1) / nt;
                P1 = Dec;
                Nt = 1 + floor(10*abs(sin(0.5*pi*t)));
                interval = 0 : 2*Nt-1;
                interval = interval/2/Nt;
                for j = 1 : Nt
                    P1(P1>(interval(2*j-1)) & P1<(interval(2*j))) = [];
                end
                P2 = 1 - P1;
                pf(:,1) = P1 ;
                pf(:,2) = P2 ;
                P(i) = struct('PF',pf);
            end 
        end
    end
end