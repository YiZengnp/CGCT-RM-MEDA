function Population = CGCT(Problem,Population,boundary,N,D,M,maxgen,ft,nt,preEvolution)

    % Initialization
    gen = 1;
    number = 1;

    % RMMEDA
    Population(number,:) = RMMEDA(Problem,ft,nt,gen,N,D,preEvolution,Population(number,:),boundary);

    AllCentroid = [];
    AllDecVar = zeros(N,D,maxgen);

    %% Optimization
    while maxgen>gen

        AllDecVar(:,:,gen) = Population(number,:).decs;

        %% Change Detection
        change = ChangeDetection(Population(number,randperm(N,round(0.1*N))),Problem,ft,nt,gen,D,preEvolution);

        %% Change Response
        if change > 1e-6
            fprintf(' %d',number);


            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % ----------------------- 写法耗时-----------------------------
            PopDec = Population(number, :).decs;
            FrontNo = NDSort(Population(number, :).objs, N);
            AllCentroid = [AllCentroid;mean(PopDec(FrontNo==1,:),1)];
            K = 5;
            % 进化过程中最后一代的模型信息已经有了，这里为了方便编程这里重新算一遍
            [Model{number},probability{number}] = LocalPCA(AllDecVar(:,:,gen-1),M,K);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            

            if number < 3
                % LSTM 从第3个环境开始预测
                numRandSample = floor(N/2);
                Lower = repmat(boundary.lower,numRandSample,1);
                Upper = repmat(boundary.upper,numRandSample,1);
                SampleDec = unifrnd(Lower,Upper);

                numRemain = N - numRandSample;
                RemainDec = PopDec(randperm(N,numRemain), :);

                Population(number+1,:) = Individual(Problem,ft,nt,gen,[],D,preEvolution,[SampleDec;RemainDec]);
            else
                p = 25;
                if size(AllCentroid,1) > p
                    AllCentroid(1,:) = [];
                end
                numTimeSeries = size(AllCentroid, 1);
                meanValue = mean(AllCentroid,1);
                stdValue = std(AllCentroid,1);
                decentroidAllCentroid = (AllCentroid-meanValue)./repmat(stdValue,numTimeSeries,1);
                XTrainCell = {decentroidAllCentroid(1:end-1,:)'};
                YTrainCell = {decentroidAllCentroid(2:end,:)'};


                % ------------------- LSTM network ------------------------
                numInput = D;
                numOutput = D;
                layers = [
                    sequenceInputLayer(numInput)
                    lstmLayer(64, 'OutputMode', 'sequence')
                    lstmLayer(128, 'OutputMode', 'sequence')
                    fullyConnectedLayer(numOutput)
                    regressionLayer
                    ];
                options = trainingOptions('adam', ...
                    'MaxEpochs', 100, ...
                    'GradientThreshold', 1, ...
                    'InitialLearnRate', 0.01, ...
                    'Verbose', 0);
                net = trainNetwork(XTrainCell,YTrainCell,layers,options);
                YPredCell = predict(net, YTrainCell);
                Vectors = zeros(K, D);
                for k = 1: K
                    Vectors(k, :) = Model{end}(k).mean - AllCentroid(end,:);
                end
                newClusterCenters = (YPredCell{1}(:,end)'.*stdValue+meanValue)+Vectors;


                % ---------------- Cluster Matching -----------------------
                % ------------------- cluster center ----------------------
                lastlastModel = Model{number-1};
                lastModel = Model{number};
                lastProbability = probability{number};
                lastlastClusterCenters = zeros(K,D);
                lastClusterCenters = zeros(K,D);
                for k = 1:K
                    lastlastClusterCenters(k,:) = lastlastModel(k).mean;
                    lastClusterCenters(k,:) = lastModel(k).mean;
                end
                % ---------------------- matching -------------------------
                dist = zeros(K,K);
                for k = 1: K
                    dist(:,k) = sum((lastlastClusterCenters-lastClusterCenters)*lastModel(k).PI.*(lastlastClusterCenters-lastClusterCenters),2);
                end
                Match = zeros(1, K);                    % 存储每列最小值的行索引
                usedRows = false(1, K);                 % 标记哪些行已经被选过
                for col = 1:K
                    [~, minRow] = min(dist(:, col));    % 找到该列的最小值及其行索引
                    while usedRows(minRow)              % 确保该行索引没有被选中过
                        dist(minRow,col) = inf;         % 如果该行已经被使用过, 将该行的最小值设为无穷大，避免重复选择
                        [~,minRow] = min(dist(:,col));  % 重新计算最小值的行
                    end
                    Match(col) = minRow;                % 记录该行索引
                    usedRows(minRow) = true;            % 标记为已使用
                end


                % ---------------- Generate Offspring ---------------------
                OffspringDec = zeros(N,D);
                for i = 1 : N
                    k = find(rand<=lastProbability,1);  % Select one cluster by Roulette-wheel selection
                    if ~isempty(lastModel(k).eVector) && ~isempty(lastlastModel(Match(k)).eVector)
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % ------------------ Boundary ---------------------
                        lastlastLower = lastlastModel(Match(k)).a - (lastlastModel(Match(k)).b-lastlastModel(Match(k)).a);
                        lastlastUpper = lastlastModel(Match(k)).b + (lastlastModel(Match(k)).b-lastlastModel(Match(k)).a);
                        lastLower = lastModel(k).a - (lastModel(k).b-lastModel(k).a);
                        lastUpper = lastModel(k).b + (lastModel(k).b-lastModel(k).a);
                        Lower = 1.25 * (lastLower + (lastLower - lastlastLower));
                        Upper = 1.25 * (lastUpper + (lastUpper - lastlastUpper));
                        % ------------------- Rotate ----------------------
                        P = lastlastModel(Match(k)).eVector(:,1:M-1)';
                        Q = lastModel(k).eVector(:,1:M-1)';
                        Pk = Q*KernelMatrix(P,P)';
                        Qk = KernelMatrix(P,P)*KernelMatrix(P,P)';
                        Mk = Pk*pinv(Qk);
                        V = Mk*KernelMatrix(P,Q);
                        % -------------------- Noise ----------------------
                        trial = rand(1,M-1).*(Upper-Lower) + Lower;
                        lastlastSigma = sum(abs(lastlastModel(Match(k)).eValue(M:D)))/(D-M+1);
                        lastSigma = sum(abs(lastModel(k).eValue(M:D)))/(D-M+1);
                        curSigma = 0.5 * (lastSigma + lastlastSigma);
                        % ------------------- Sample ----------------------
                        OffspringDec(i,:) = newClusterCenters(k,:) + trial*V + randn(1,D)*sqrt(curSigma);


                    elseif ~isempty(lastModel(k).eVector)
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % ------------------ Boundary ---------------------
                        Lower = lastModel(k).a - 0.25*(lastModel(k).b-lastModel(k).a);
                        Upper = lastModel(k).b + 0.25*(lastModel(k).b-lastModel(k).a);
                        % -------------------- Noise ----------------------
                        trial = rand(1,M-1).*(Upper-Lower) + Lower;
                        curSigma = sum(abs(lastModel(k).eValue(M:D)))/(D-M+1);
                        % ------------------- Sample ----------------------
                        OffspringDec(i,:) = newClusterCenters(k,:) + trial*lastModel(k).eVector(:,1:M-1)' + randn(1,D)*sqrt(curSigma);


                    elseif ~isempty(lastlastModel(k2).eVector)
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % ------------------ Boundary ---------------------
                        Lower = lastlastModel(Match(k)).a - 0.25*(lastlastModel(Match(k)).b-lastlastModel(Match(k)).a);
                        Upper = lastlastModel(Match(k)).b + 0.25*(lastlastModel(Match(k)).b-lastlastModel(Match(k)).a);
                        % -------------------- Noise ----------------------
                        trial = rand(1,M-1).*(Upper-Lower) + Lower;
                        curSigma = sum(abs(lastlastModel(k2).eValue(M:D)))/(D-M+1);
                        % ------------------- Sample ----------------------
                        OffspringDec(i,:) = newClusterCenters(k2,:) + trial*lastlastModel(k2).eVector(:,1:M-1)' + randn(1,D)*sqrt(curSigma);
                    

                    else
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % ------------------- Sample ----------------------
                        OffspringDec(i,:) = newClusterCenters(k,:) + randn(1,D);
                    end
                end
                % -------------------- Repair Boundary --------------------
                OffspringDec = real(OffspringDec);
                Lower = boundary.lower;
                exLower = 0.5*(PopDec+Lower);
                exFlag = OffspringDec<repmat(Lower,N,1);
                OffspringDec(exFlag) = exLower(exFlag);
                Upper = boundary.upper;
                exUpper = 0.5*(PopDec+Upper);
                exFlag = OffspringDec>repmat(Upper,N,1);
                OffspringDec(exFlag) = exUpper(exFlag);


                % ----------------- Evaluate Offspring --------------------
                Population(number+1,:) = Individual(Problem,ft,nt,gen,[],D,preEvolution,OffspringDec);
            end
            % -------------------------------------------------------------
            number = number+1;
        end

        % ------------------------- Static MOEA ---------------------------
        Population(number,:) = RMMEDA(Problem,ft,nt,gen,N,D,preEvolution,Population(number,:),boundary);
        gen = gen + 1;
    end
end



function change = ChangeDetection(Population,Problem,ft,nt,gen,D,preEvolution)
    % Dectect the change
    Dec = Population.decs;
    [Current,~] = Individual(Problem,ft,nt,gen,[],D,preEvolution,Dec);
    obj1 = Population.objs;
    obj2 = Current.objs;
    change = mean(sum(abs(obj1-obj2),2));
end


function K = KernelMatrix(X1,X2)

    n1sq = sum(X1.^2,1);
    n1 = size(X1,2);
    
    if isempty(X2)
        D = (ones(n1,1)*n1sq)' + ones(n1,1)*n1sq -2*X1'*X1;
    else
        n2sq = sum(X2.^2,1);
        n2 = size(X2,2);
        D = (ones(n2,1)*n1sq)' + ones(n1,1)*n2sq -2*X1'*X2;
    end
    K = exp(-D/(2*2^2));

end